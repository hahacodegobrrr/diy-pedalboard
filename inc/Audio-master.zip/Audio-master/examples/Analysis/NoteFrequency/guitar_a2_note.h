extern const unsigned int guitar_a2_note[52184];
